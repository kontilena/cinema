//
//  cinemaApp.swift
//  cinema
//
//  Created by Кирилл Кузнецов on 23/11/2022.
//

import SwiftUI

@main
struct cinemaApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
